// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// Drivetrain           drivetrain    9, 10, 1, 3     
// StackAngle           motor         5               
// IntakeAngle          motor         4               
// CubeSuck1            motor         6               
// CubeSuck2            motor         7               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
}

void autonomous( void ) {
// Auton Stuffs 
    
  Brain.setTimer(15,timeUnits::sec);

  Brain.Screen.clearScreen( vex::color::black );
  Brain.Screen.print("          AUTONOMOUS");

  
}

void drivercontrol( void ) {
  
  while (true) {
    
    // Autonomous Switch
    if(Controller1.ButtonB.pressing()){
      autonomous();
    }


  }
}